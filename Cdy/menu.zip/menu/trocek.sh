#!/bin/bash
DF='\e[39m'
Bold='\e[1m'
Blink='\e[5m'
yell='\e[33m'
red='\e[31m'
green='\e[32m'
blue='\e[34m'
PURPLE='\e[35m'
cyan='\e[36m'
Lred='\e[91m'
Lgreen='\e[92m'
Lyellow='\e[93m'
NC='\e[0m'
GREEN='\033[0;32m'
ORANGE='\033[0;33m'
LIGHT='\033[0;37m'
grenbo="\e[92;1m"


yellow="\033[0;33m"
ungu="\033[0;35m"
Xark="\033[0m"
BlueCyan="\033[5;36m"
WhiteBe="\033[5;37m"
GreenBe="\033[5;32m"
YellowBe="\033[5;33m"
BlueBe="\033[5;34m"

# . Liner 
function baris_panjang() {
  echo -e "${BlueCyan} ——————————————————————————————————— ${Xark} "
}

function Lunatic_Banner() {
clear
baris_panjang
echo -e "${ungu}         PUNCAK STAR3      ${Xark} "
baris_panjang
}

function Sc_Credit(){
sleep 1
baris_panjang
echo -e "${ungu}  Terimakasih Telah Menggunakan ${Xark}"
echo -e "${ungu}          Script Credit ${Xark}"
echo -e "${ungu}        PUNCAK STAR3 ${Xark}"
baris_panjang
exit 1
}

clear
function con() {
    local -i bytes=$1;
    if [[ $bytes -lt 1024 ]]; then
        echo "${bytes}B"
    elif [[ $bytes -lt 1048576 ]]; then
        echo "$(( (bytes + 1023)/1024 ))KB"
    elif [[ $bytes -lt 1073741824 ]]; then
        echo "$(( (bytes + 1048575)/1048576 ))MB"
    else
        echo "$(( (bytes + 1073741823)/1073741824 ))GB"
    fi
}
echo -n > /tmp/other.txt
data=( `cat /etc/xray/config.json | grep '^#!' | cut -d ' ' -f 2 | sort | uniq`);

echo -e ""
Lunatic_Banner
baris_panjang
echo -e "${YellowBe}            CHECK TROJAN      ${Xark} "
baris_panjang

for akun in "${data[@]}"
do
if [[ -z "$akun" ]]; then
akun="tidakada"
fi
echo -n > /tmp/iptrojan.txt
data2=( `cat /var/log/xray/access.log | tail -n 500 | cut -d " " -f 3 | sed 's/tcp://g' | cut -d ":" -f 1 | sort | uniq`);
for ip in "${data2[@]}"
do
jum=$(cat /var/log/xray/access.log | grep -w "$akun" | tail -n 500 | cut -d " " -f 3 | sed 's/tcp://g' | cut -d ":" -f 1 | grep -w "$ip" | sort | uniq)
if [[ "$jum" = "$ip" ]]; then
echo "$jum" >> /tmp/iptrojan.txt
else
echo "$ip" >> /tmp/other.txt
fi
jum2=$(cat /tmp/iptrojan.txt)
sed -i "/$jum2/d" /tmp/other.txt > /dev/null 2>&1
done
jum=$(cat /tmp/iptrojan.txt)
if [[ -z "$jum" ]]; then
echo > /dev/null
else
iplimit=$(cat /etc/LT/limit/trojan/ip/${akun})
jum2=$(cat /tmp/iptrojan.txt | wc -l)
byte=$(cat /etc/LT/trojan/${akun})
lim=$(con ${byte})
wey=$(cat /etc/LT/limit/trojan/${akun})
gb=$(con ${wey})
lastlogin=$(cat /var/log/xray/access.log | grep -w "$akun" | tail -n 500 | cut -d " " -f 2 | tail -1)
echo -e " \033[1;36m┌──────────────────────────────────────┐\033[0m"
printf "  %-13s %-7s %-8s %2s\n" "  UserName    : ${akun}"
printf "  %-13s %-7s %-8s %2s\n" "  Login       : $lastlogin"
printf "  %-13s %-7s %-8s %2s\n" "  Usage Quota : ${gb}" 
printf "  %-13s %-7s %-8s %2s\n" "  Limit Quota : ${lim}" 
printf "  %-13s %-7s %-8s %2s\n" "  Limit IP    : $iplimit" 
printf "  %-13s %-7s %-8s %2s\n" "  Login IP    : $jum2" 
echo -e " \033[1;36m└──────────────────────────────────────┘\033[0m"
fi 
rm -rf /tmp/iptrojan.txt
done
rm -rf /tmp/other.txt

echo ""
baris_panjang
